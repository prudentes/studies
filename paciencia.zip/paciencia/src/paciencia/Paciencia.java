/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paciencia;

import java.util.Scanner;
import java.util.Arrays;
import java.util.Stack;
import java.util.LinkedList;
import java.util.List;
/**
 *
 * @author F7023259
 */
public class Paciencia {
    
    
    private int movimentos = 0;
    private int num_cartas;
    private baralho baralho = new baralho();
    
    private Stack<carta> estoque;
    private Stack<carta> descarte;

    private Stack<carta> fundacao1;
    private Stack<carta> fundacao2;
    private Stack<carta> fundacao3;
    private Stack<carta> fundacao4;
    
    private LinkedList<carta> pilha1;
    private LinkedList<carta> pilha2;
    private LinkedList<carta> pilha3;
    private LinkedList<carta> pilha4;
    private LinkedList<carta> pilha5;
    private LinkedList<carta> pilha6;
    private LinkedList<carta> pilha7;
   
    public Paciencia() {
        this.num_cartas = 1;
    }
    
    public Paciencia(int a) {
        this.num_cartas = a;
    }
    
    public void iniciaJogo() {
        this.zerajogo();
        
        baralho.embaralhar(52);
        
        this.distribuir();
    }
    
    public void distribuir() {
        LinkedList[] ordemDistribuir = {this.pilha1, this.pilha2, this.pilha3, this.pilha4, this.pilha5, this.pilha6, this.pilha7};
        int contador = 0;
        for (int i = 0; i < ordemDistribuir.length; i++) {
            for (int j = 0; j <= i; j++) { 
                if (j == i) {
                    this.baralho.get_carta(contador).set_escondida(false);
                }
                ordemDistribuir[i].add(this.baralho.get_carta(contador));
                contador++;
            }
            
        }
        for (int i = contador; i < 52; i++) {
            this.estoque.add(this.baralho.get_carta(i));
        }
    }
    
    public void zerajogo() {
        this.baralho = new baralho();
    
        this.estoque = new Stack();
        this.descarte = new Stack();

        this.fundacao1 = new Stack();
        this.fundacao2 = new Stack();
        this.fundacao3 = new Stack();
        this.fundacao4 = new Stack();
        
        this.pilha1 = new LinkedList();
        this.pilha2 = new LinkedList();
        this.pilha3 = new LinkedList();
        this.pilha4 = new LinkedList();
        this.pilha5 = new LinkedList();
        this.pilha6 = new LinkedList();
        this.pilha7 = new LinkedList();
        this.movimentos = 0;
    }
    
    public void imprimeGameTop() {
        System.out.println(" ╔═══════════════════════════════════════\t╗ ");
        List<Stack<carta>> imprimirOrdem = Arrays.asList(this.estoque, this.descarte, null, this.fundacao1, this.fundacao2, this.fundacao3, this.fundacao4);
        int i = 0;
        while (i < this.num_cartas) {
            int j = 0;
            System.out.print(" ║ ");
            while (j < imprimirOrdem.size()) {
                System.out.print("\t");
                if (i == 0) {
                    if (imprimirOrdem.get(j) == (null)) {
                        System.out.print("     ");
                    } else {
                        if (!imprimirOrdem.get(j).isEmpty()) {
                            if (imprimirOrdem.get(j) == this.descarte) {
                                if (i < imprimirOrdem.get(j).size()) {
                                    System.out.print(imprimirOrdem.get(j).get(imprimirOrdem.get(j).size() - this.num_cartas + i).validacao("get_carta"));
                                } else {
                                    System.out.print("  ▢  ");
                                }
                            } else {
                                System.out.print(imprimirOrdem.get(j).peek().validacao("get_carta"));
                            }
                        } else {
                            System.out.print("  ▢  ");
                        }
                    }
                } else {
                    if (imprimirOrdem.get(j) == this.descarte) {
                        if (i < imprimirOrdem.get(j).size()) {
                            System.out.print(imprimirOrdem.get(j).get(imprimirOrdem.get(j).size() - this.num_cartas + i).validacao("get_carta"));
                        } else {
                            System.out.print("  ▢  ");
                        }
                    } else {
                        System.out.print("     ");
                    }
                }
                j++;    
            }
            System.out.println("\t║ ");
            i++;
        }

        System.out.println(" ╟───────────────────────────────────────\t╢ ");
    }

    public void imprimeGameBottom() {
        List<LinkedList<carta>> imprimirOrdem = Arrays.asList(this.pilha1, this.pilha2, this.pilha3, this.pilha4, this.pilha5, this.pilha6, this.pilha7);
        int i = 0;
        while (i >= 0) {
            int j = 0;
            int contador = 0;
            System.out.print(" ║ ");
            while (j < imprimirOrdem.size()) {
                System.out.print("\t");
                if (i == 0) {
                    if (imprimirOrdem.get(j) == (null)) {
                        System.out.print("     ");
                    } else {
                        if (!imprimirOrdem.get(j).isEmpty()) {
                            System.out.print(imprimirOrdem.get(j).get(i).validacao("get_carta"));
                        } else {
                            System.out.print("  ▢  ");
                        }
                    }
                    contador++;
                } else {
                    if (i < imprimirOrdem.get(j).size()) {
                        System.out.print(imprimirOrdem.get(j).get(i).validacao("get_carta"));
                        contador++;
                    } else {
                        System.out.print("     ");
                    }
                }
                j++;
            }
            System.out.println("\t║ ");
            if (contador == 0) {
                i = -1;
            } else {
                i++;
            }
        }
        System.out.println(" ╚═══════════════════════════════════════\t╝ ");
    }
    public boolean imprimeGameMenu() {
        boolean retorno = false;
        Scanner sc = new Scanner(System.in);
        int i = 0;
        int a = 0;
        while (i == 0) {
            i++;
            System.out.println();
            System.out.println("(R) Reiniciar Jogo");
            System.out.println("(S) Sair do Jogo");
            System.out.println("(E) Sacar carta do estoque");
            System.out.println("(D) Selecionar carta do descarte");
            System.out.println("(F-1) Selecionar carta da fundação 1");
            System.out.println("(F-2) Selecionar carta da fundação 2");
            System.out.println("(F-3) Selecionar carta da fundação 3");
            System.out.println("(F-4) Selecionar carta da fundação 4");
            System.out.println("(P-1) Selecionar carta(s) da pilha 1");
            System.out.println("(P-2) Selecionar carta(s) da pilha 2");
            System.out.println("(P-3) Selecionar carta(s) da pilha 3");
            System.out.println("(P-4) Selecionar carta(s) da pilha 4");
            System.out.println("(P-5) Selecionar carta(s) da pilha 5");
            System.out.println("(P-6) Selecionar carta(s) da pilha 6");
            System.out.println("(P-7) Selecionar carta(s) da pilha 7");

            System.out.println();

            System.out.println(" --> Digite o valor correspondente a opção desejada: ");
            
            carta b;

            switch (sc.next()) {
                case "R":
                    zerajogo();
                    iniciaJogo();
                    retorno = true;
                    break;
                case "S":
                    retorno = false;
                    break;
                case "E":
                    sacarEstoque();
                    retorno = true;
                    break;
                case "D":
                    if (this.descarte.isEmpty()){
                        System.out.println("O estoque está vazio!");
                    } else {
                        selecionarCarta(this.descarte, 1);
                        i = 0;
                    }
                    retorno = true;
                    break;
                case "F-1":
                    if (this.fundacao1.isEmpty()){
                        System.out.println("A fundação1 está vazia!");
                    } else {
                        selecionarCarta(this.fundacao1, 1);
                        i = 0;
                    }
                    retorno = true;
                    break;
                case "F-2":
                    if (this.fundacao2.isEmpty()){
                        System.out.println("A fundação2 está vazia!");
                    } else {
                        selecionarCarta(this.fundacao2, 1);
                        i = 0;
                    }
                    retorno = true;
                    break;
                case "F-3":
                    if (this.fundacao3.isEmpty()){
                        System.out.println("A fundação3 está vazia!");
                    } else {
                        selecionarCarta(this.fundacao3, 1);
                        i = 0;
                    }
                    retorno = true;
                    break;
                case "F-4":
                    if (this.fundacao4.isEmpty()){
                        System.out.println("A fundação4 está vazia!");
                    } else {
                        selecionarCarta(this.fundacao4, 1);
                        i = 0;
                    }
                    retorno = true;
                    break;
                case "P-1":
                        System.out.println("Quantas cartas você quer mover?");
                        a = sc.nextInt();
                    retorno = true;
                    break;
                case "P-2":
                        System.out.println("Quantas cartas você quer mover?");
                        a = sc.nextInt();
                    retorno = true;
                    break;
                case "P-3":
                        System.out.println("Quantas cartas você quer mover?");
                        a = sc.nextInt();
                    retorno = true;
                    break;
                case "P-4":
                        System.out.println("Quantas cartas você quer mover?");
                        a = sc.nextInt();
                    retorno = true;
                    break;
                case "P-5":
                        System.out.println("Quantas cartas você quer mover?");
                        a = sc.nextInt();
                    retorno = true;
                    break;
                case "P-6":
                        System.out.println("Quantas cartas você quer mover?");
                        a = sc.nextInt();
                    retorno = true;
                    break;
                case "P-7":
                        System.out.println("Quantas cartas você quer mover?");
                        a = sc.nextInt();
                    retorno = true;
                    break;
                default:
                    System.out.println("Opção inválida! Tente novamente!");
                    i = 0;
                    retorno = true;
                    break;
            }
        }
        return retorno;
    }
    
    public void atualizarEstoque() {      
            if (this.descarte.isEmpty()){
                System.out.println("Não há cartas para atualizar estoque!!!");
            } else {
                while (!this.descarte.isEmpty()) {
                    carta a = this.descarte.pop();
                    a.set_escondida(true);
                    this.estoque.push(a);
                }
                this.movimentos++;
            }
    }
    
    public void sacarEstoque() {
        if (this.estoque.isEmpty()){
            System.out.println("O estoque está vazio!");
            atualizarEstoque();
        } else {
            for (int i = 0; i < this.num_cartas; i++) {
                if (!this.estoque.isEmpty()) {
                    carta a = this.estoque.pop();
                    a.set_escondida(false);            
                    this.descarte.push(a);
                }
            }
            this.movimentos++;
        }
    }
    
    public void imprimeGame() {
        boolean condicao = true;
        
        while (condicao) {
            imprimeGameTop();
            imprimeGameBottom();
            condicao = imprimeGameMenu();
        }
    }
    
    public void moverCarta(carta a, int b) {
        
    }
    
    public void moverCartaFundacao(carta a, Stack<carta> b) {
        if (b.isEmpty()) {
            
        } else {
            if (a.get_naipe() == b.peek().get_naipe()) {
                if (a.get_valor() == b.peek().get_valor() + 1) {
                    
                } else {
                    System.out.println("A carta possui um valor diferente do valour subsequente ao da fundação!");
                }
            } else {
                System.out.println("A carta possui naipe diferente da fundação!");
            }
        }
    }
    
    public void selecionarCarta(Object a, int b) {
        Scanner sc = new Scanner(System.in);

        System.out.println();
        
        System.out.println("(F-1) mover carta da fundação 1");
        System.out.println("(F-2) mover carta da fundação 2");
        System.out.println("(F-3) mover carta da fundação 3");
        System.out.println("(F-4) mover carta da fundação 4");

        System.out.println("(P-1) Selecionar carta(s) da pilha 1");
        System.out.println("(P-2) Selecionar carta(s) da pilha 2");
        System.out.println("(P-3) Selecionar carta(s) da pilha 3");
        System.out.println("(P-4) Selecionar carta(s) da pilha 4");
        System.out.println("(P-5) Selecionar carta(s) da pilha 5");
        System.out.println("(P-6) Selecionar carta(s) da pilha 6");
        System.out.println("(P-7) Selecionar carta(s) da pilha 7");

        System.out.println();

        System.out.println(" --> Digite o valor correspondente a opção desejada: ");
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
   
        Paciencia game = new Paciencia();
        
        game.iniciaJogo();
        
        game.baralho.get_cartasStr();
        
        game.imprimeGame();
    }
    
}
